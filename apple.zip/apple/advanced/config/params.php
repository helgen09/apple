<?php

return [
    'noreplyEmail' => 'noreply@utverdil.ru',
    'adminEmail' => 'admin@utverdil.ru',
    'supportEmail' => 'support@utverdil.ru',
    'user.passwordResetTokenExpire' => 3600,
];
