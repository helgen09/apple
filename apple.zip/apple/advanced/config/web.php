<?php

$params = require(__DIR__ . '/params.php');

$config = [
    'id' => 'basic',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],

    'language' => 'ru-RU',
    // 'sourceLanguage' => 'en-US',

    'components' => [
        'request' => [
            'baseUrl' => '',
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => '7gkgy9bOF9r2fxKv7vg05mcHPPBsJ7OS',
            'enableCsrfValidation' => true,
        ],

        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],

        'user' => [
            'identityClass' => 'app\models\common\User',
            'enableAutoLogin' => true,
            'loginUrl' => array('/login'),
        ],

        'authManager' => [
            'class' => 'yii\rbac\DbManager',
        ],

        'errorHandler' => [
            'errorAction' => 'site/error',
        ],

        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => false,
            'messageConfig' => [
                'charset' => 'UTF-8',
                'from' => ['noreply@utverdil.ru' => 'Утвердил.ру'],
            ],
            'transport' => [
                'class' => 'Swift_SmtpTransport',
                'host' => 'smtp.yandex.ru',
                'username' => 'noreply@utverdil.ru',
                'password' => '123456q',
                'port' => '465',
                'encryption' => 'ssl',

            ],
        ],

        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],

        'db' => require(__DIR__ . '/db.php'),

        'i18n' => [
            'translations' => [
                'app*' => [
                    'class' => 'yii\i18n\PhpMessageSource',
                    'basePath' => '@app/i18n',
                    'sourceLanguage' => 'en-US',
                    'on missingTranslation' => ['app\components\TranslationEventHandler', 'handleMissingTranslation']
                ],
            ],
        ],

        'imageCache' => [
            'class' => 'iutbay\yii2imagecache\ImageCache',
            'sourcePath' => '@app/web/images',
            'sourceUrl' => '@web/images',
            //'thumbsPath' => '@app/web/thumbs',
            //'thumbsUrl' => '@web/thumbs',
            //'sizes' => [
            //    'thumb' => [150, 150],
            //    'medium' => [300, 300],
            //    'large' => [600, 600],
            //],
        ],
        
        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            // 'enableStrictParsing' => true,
            'rules' => [
                // '<controller:\w+>/<action:\w+>' => '<controller>/<action>',
                // '<controller:\w+>/<id:\d+>/<slug:\w+>' => '<controller>/view',
                '/' => 'site/index',

                'terms' => 'site/terms',

                'login' => 'user/login',
                'logout' => 'user/logout',
                'signup' => 'user/signup',
                'request-password-reset' => 'user/request-password-reset',
                'password-reset' => 'user/password-reset',

                'profile/<id:\d+>' => 'profile/view',
                'profile/edit' => 'profile/update',

                'categories' => 'categories/index',
                'categories/<id:\d+>' => 'categories/view',

                'projects' => 'projects/index',
                'projects/<id:\d+>' => 'projects/view',
                'projects/<id:\d+>/edit' => 'projects/update',
                'projects/<id:\d+>/download' => 'projects/download',
                'projects/create' => 'projects/create',
                'projects/my' => 'projects/my',

                'projects/moderation' => 'projects/moderation',
                'projects/moderation/<id:\d+>' => 'projects/moderation-view',
                'projects/moderation/<id:\d+>/publish' => 'projects/moderation-publish',
                'projects/moderation/<id:\d+>/reject' => 'projects/moderation-reject',


                'tasks' => 'tasks/index',
                'tasks/<id:\d+>' => 'tasks/view',
                'tasks/create' => 'tasks/create',

                'tasks/moderation' => 'tasks/moderation',

                'engineers' => 'engineers/index',
                'engineers/<id:\d+>' => 'engineers/view',

                'wallet' => 'wallet/view',
                'wallet/add-funds' => 'wallet/add-funds',
                'wallet/withdrawal' => 'wallet/withdrawal',

                'money/transactions' => 'booker/index',
                'money/withdrawals' => 'booker/withdrawals',
            ],
        ],

        'view' => [
            'class' => 'yii\web\View',
            'renderers' => [
                'twig' => [
                    'class' => 'yii\twig\ViewRenderer',
                    'cachePath' => '@runtime/Twig/cache',
                    'options' => [
                        'auto_reload' => true,
                    ],
                    'globals' => [
                        'html' => '\yii\helpers\Html',
                        'url' => '\yii\helpers\Url',
                        'yii' => '\Yii',
                        'Alert' => 'app\widgets\Alert',
                    ],
                    'uses' => [
                        'yii\bootstrap',
                        'yii\widgets',
                        'yii\grid',
                    ],
                ],
            ],
        ],
    ],
    'layout' => 'base.html.twig',
    'params' => $params,
];

if (YII_ENV_DEV) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = [
        'class' => 'yii\debug\Module',
    ];

    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] = [
        'class' => 'yii\gii\Module',
    ];
}

return $config;
