<?php
namespace backend\controllers;

use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use app\models\Apple;

/**
 * Site controller
 */
class AppleController extends Controller
{

    public function actionIndex()
    {
        $apples=Apple::find()->all();
        return $this->render('index', [
            'apples' => $apples,
        ]);
    }

    public function actionCreate()
    {
        $colors=Array('#8d0000','#fff67a','#17452d','#ee5859','#5c7342', 'red', 'green', 'yellow');
        for ($i=0;$i<rand(1,10);$i++)
        {
            $apple=new Apple($colors[rand(0,count($colors))]);
            $apple->insert(false);
        }
        $apples=Apple::find()->all();
        return $this->render('index', [
            'apples' => $apples,
        ]);
    }

    public function actionEat($id, $value)
    {
        $value=(int)$value;
        if ($value>0 && $value<101)
        {
            $apple=Apple::find()->where('id='.$id)->one();
            if (!is_null($apple))
            {
                if ($apple->state==Apple::STATUS_ON_GROUND)
                {
                    if ($apple->check_rotten_status())
                    {
                        $apple->save();
                        Yii::$app->session->setFlash('warning', 'Яблоко испортилось.');
                    }
                    else
                    {
                        if (($apple->weight+$value/100)<1)
                        {
                            $apple->weight=$apple->weight+$value/100;
                            $apple->save();
                            Yii::$app->session->setFlash('success', 'Успешно откушено '.$value.'% яблока.');
                        }
                        else if( (($apple->weight+$value/100)==1) || ($apple->weight==0 && $value==100) )
                        {
                            $apple->delete();
                            Yii::$app->session->setFlash('success', 'Яблоко съедено.');
                        }
                    }
                }
                else if($apple->state==Apple::STATUS_ON_TREE)
                {
                    Yii::$app->session->setFlash('warning', 'Извините, но это яблоко еще на дереве.');
                }
                else if ($apple->state==Apple::STATUS_ROTTEN)
                {
                    Yii::$app->session->setFlash('error', 'Этим яблоком можно отравиться, извините, мы этого допустить не можем.');
                }
            }
            else
            {
                Yii::$app->session->setFlash('error', 'Такого яблока не найдено.');
            }
        }
        $apples=Apple::find()->all();
        return $this->render('index', [
            'apples' => $apples,
        ]);
    }

    public function actionFail($id)
    {
        $apple=Apple::find()->where('id='.$id)->one();
        if (!is_null($apple))
        {
            if ($apple->state==Apple::STATUS_ON_TREE)
            {
                $apple->fallToGround();
                $apple->save();
                Yii::$app->session->setFlash('success', 'Яблоко упало.');
            }
            else if ($apple->state==Apple::STATUS_ROTTEN)
            {
                Yii::$app->session->setFlash('error', 'Это яблоко давно испортилось.');
            }
            else if ($apple->state==Apple::STATUS_ON_GROUND)
            {
                Yii::$app->session->setFlash('warning', 'Это яблоко уже на земле.');
            }
        }
        else
        {
            Yii::$app->session->setFlash('error', 'Такого яблока не найдено.');
        }
        $apples=Apple::find()->all();
        return $this->render('index', [
            'apples' => $apples,
        ]);
    }
}
