<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">
    <div class="body-content">

        <div class="row">
                <h2>Apples</h2>
                <div class="row">
                    <a class="btn btn-lg btn-success" href="/admin/apple/create">Создать яблоки</a>
                </div>
                <? 
                    if (count($apples)==0) 
                    {
                        echo 'Яблок пока нет';
                    }
                    else
                    {
                        foreach ($apples as $apple) {
                            echo '<p><div style="display: inline-block;">';
                            echo '<div style="float: left;"><img style="width: 100px;height: 100px;background: '.$apple['color'].';-moz-border-radius: 50px;-webkit-border-radius: 50px;border-radius: 50px;"/></div><div style="float: left;"><input style="width: 150px;margin: 30px 0 0 5px;float: left;" type="number" id="eat_value_'.$apple['id'].'" class="form-control eat_value"  min="0" max="'.(100-$apple->weight*100).'" value="0"><a id="eat_btn_'.$apple['id'].'" class="btn btn-success eat_btn" style="margin: 30px 0 0 5px;float: left;" onclick="eat('.$apple['id'].')">Съесть</a><a id="down_btn_'.$apple['id'].'" class="btn btn-warning" style="margin: 30px 0 0 5px;float: left;" href="/admin/apple/fail?id='.$apple['id'].'">Стрясти с дерева</a></div>';
                            echo '</div></p>';
                        }
                    }
                ?>
        </div>

    </div>
</div>
<?
$script = <<< JS
    function eat(id)
    {
        var value=document.getElementById("eat_value_"+id).value;
        var max_value=document.getElementById("eat_value_"+id).getAttribute("max");

        if (Number(value)<=Number(max_value))
        {
            window.location = "/admin/apple/eat?id="+id+"&value="+value;
        }
        else
        {
            alert('Столько съесть невозможно. Поробуйте откусить '+max_value+'%');
        }
    }
JS;
//маркер конца строки, обязательно сразу, без пробелов и табуляции
$this->registerJs($script, yii\web\View::POS_END);
?>