<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;
use yii\behaviors\TimestampBehavior;

class apple extends ActiveRecord
{	
    const STATUS_ROTTEN = 0;
    const STATUS_ON_GROUND = 10;
    const STATUS_ON_TREE = 100;

    public function rules()
    {
        return [
            [['color',], 'required'],
            [['weight', 'state', 'falltoground_at'], 'safe'],
            ['color', 'default', 'value' => $this->color],
            ['weight', 'default', 'value' => 0],
            ['falltoground_at', 'default', 'value' => 0],
            ['state', 'default', 'value' => self::STATUS_ON_TREE],
            ['state', 'in', 'range' => [self::STATUS_ROTTEN, self::STATUS_ON_GROUND, self::STATUS_ON_TREE]],
        ];
    }

    public static function tableName()
    {
        return '{{%apple}}';
    }

    public function behaviors()
    {
        return [
            TimestampBehavior::className(),
        ];
    }

    public static function getStatusesList()
    {
        return [
            self::STATUS_ROTTEN => 'Гнилое яблоко',
            self::STATUS_ON_GROUND => 'На земле',
            self::STATUS_ON_TREE => 'На дереве',
        ];
    }

    public function __construct($input_color="")
    {
        $this->color=$input_color;
    }

    public function fallToGround()
    {
        $this->state=self::STATUS_ON_GROUND;
    }

    public function check_rotten_status()
    {
        if ((time() - $this->created_at) < (5*60*60) )
        {
            return false;
        }
        else
        {
            $this->state=self::STATUS_ROTTEN; 
            return true;        
        }
    }

}
