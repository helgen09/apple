function addfavotiteproject($id)
{
	alert(id);
}

function delfavotiteproject($id)
{
	alert(id);
}